
<style>
      body {
        font-family:  'Contrail One', fantasy;
        font-size: 14px;
      }
    </style>
<?php 
include"koneksi.php";
 
if(isset($_POST['cari'])) {
	$start=$_POST['start'];
	$end=$_POST['end'];
$b=mysql_query("select * from tes where id between '$start' and '$end'");
	
}else{
$b=mysql_query("select * from tes where id between 1 and 5");
	
}

?>



        <style>
   div {
     width: 250px;
    height: 120px;
     border: 1px solid white;
	margin: 0 auto;
   }
   .dua {
    border-radius: 20px;
    font-family: arial narrow;
	font:bold;
}
   
</style>



<center>
<table width="580" border="1" cellpadding="10" cellspacing="0">
<?php
 while ($hasil=mysql_fetch_array($b)) { ?>

	<tr>
		<td><div class="dua"><p><center><b><?php echo $hasil['name1'];?></br></br>DI</br></br><?php echo $hasil['name2'];?></b></center></div></td>
		<td><div class="dua"><p><center><b><?php echo $hasil['name3'];?></br></br>DI</br></br><?php echo $hasil['name4'];?></b></center></div></td>
		
	</tr>
<?php } ?>
</table>
<p>
<form method="post">
<input type="number" name="start" placeholder="Nomor  " required> Sampai
<input type="number" name="end" placeholder="Nomor"required>
<input type="submit" name="cari">
</form>
<button onclick="window.print()">Cetak</button> <BR>

<a href="viewdata.php">Lihat Nomor Urut Undangan Disini</a>

</center>
</body>
<!---
<tr>
		<td><div class="dua"><p><center><b><?php echo $hasil['name1'];?></br><font size="2px">KETUA PENGADILAN NEGERI MALILI</font></br></br>DI</br></br><?php echo $hasil['name2'];?></b></center></div></td>
		<td><div class="dua"><p><center><?php echo $hasil['name3'];?></br><font size="2px">RSUD SAWERIGADING PALOPO</font></br></br>DI</br></br><?php echo $hasil['name4'];?></center></div></td>
		
	</tr>-->

</html>