<?php include"header.php"?>

 



<?php
include "koneksi.php";
$sql=mysql_query("select*from tes");
?>
<script type="text/javascript">
<!--
function checkAll(frm, checkedOn) {
  // have we been passed an ID
  if (typeof frm == "string") {
    frm = document.getElementById(frm);
  }
  // Get all of the inputs that are in this form
  var inputs = frm.getElementsByTagName("input");
  // for each input in the form, check if it is a checkbox
  for (var i = 0; i < inputs.length; i++) {
    if (inputs[i].type == "checkbox") {
      inputs[i].checked = checkedOn;
    }
  }
}
// -->
</script>

<script type="text/javascript">. 
$(document).ready(function() {
    $('#example').DataTable();
} );

</script>
<div class="container">
<form  method="post" enctype="multipart/form-data"  id="test_form" action="proses_hapus.php">
<table class="table">
    <thead>
            <tr><th>NO.</th>
                <th> CEK ALL <BR> <input name="all" id="all" onclick="checkAll('test_form', this.checked);" type="checkbox"></th>
                <th>NAMA</th>
                <th>ALAMAT</th>
                <th>NAMA</th>
                <th>ALAMAT</th>
              <!--  <th>ACTION</th>-->
            </tr>
	   			<?php
				
				
while($baris=mysql_fetch_array($sql))
	
{
	
?>
       </thead>

<tbody>
           <tr class="success">
		         <td><?=$baris['id'];?></td>
                <td><input type="checkbox" name ="id[]" id="hapus" value="<?=$baris['id'];?>"></td>
                <td><?=$baris['name1'];?></td>
                <td><?=$baris['name2'];?></td>
                <td><?=$baris['name3'];?></td>
                <td><?=$baris['name4'];?></td>
               <!-- <td>
				
				<button type="button" class="btn btn-primary" a href="edit.php?id=<?=$baris['id'];?>">Edit</button> || <button type="button" class="btn btn-primary" a href="hapus.php?id=<?=$baris['id'];?>">Hapus</button></td>
            </tr>-->
					<?php
}
?> 
		</tbody>

	
		</table>
		<table width="722" border="0" cellpadding="5" cellspacing="1">

  

  
    
<button type="button" class="btn btn-info btn-lg" data-toggle="modal" data-target="#myModal">HAPUS DATA</button>

<!-- Modal -->
<div id="myModal" class="modal fade" role="dialog">
  <div class="modal-dialog">

    <!-- Modal content-->
    <div class="modal-content">
      <div class="modal-header">
        <button type="button" class="close" data-dismiss="modal">&times;</button>
       
      </div>
      <div class="modal-body">
        <p>
		
		APAKAH ANDA YAKIN INGIN MENGHAPUS DATA INI ?
		</B>
		 <CENTER><button type="button" class="btn btn-default" data-dismiss="modal">TIDAK</button>||
		<button class="btn btn-primary" type="submit" value="Hapus" > YA </button> </CENTER>
</p>
   </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-default" data-dismiss="modal">Close</button>
      </div>
    </div>

  </div>
</div>
  
  
  
  
  
  
  
  
  
  
  
  
</table>
		</form>
		</div>





<?php include"footer.php"?>
