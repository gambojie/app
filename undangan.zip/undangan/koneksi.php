<?php
$_host='localhost';
$_user='root';
$_pass='';
$database='tes';
$konek=mysql_connect($_host, $_user, $_pass) or die ("Localhost Tidak Terkoneksi") ;
mysql_select_db($database) or die ("Tidak Konek Database");
?>