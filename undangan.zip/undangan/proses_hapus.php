<?php
include "koneksi.php";
$juml= count($_POST['id']);
for($i=0; $i<=($juml-1); $i++)
{
$id = $_POST["id"][$i];
$delete = mysql_query("delete from tes where id='$id'");
}
if($delete)
{
echo "<meta http-equiv=\"refresh\" content=\"0;URL=viewdata.php\">";
}
?>