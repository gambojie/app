<!DOCTYPE html>
<html lang="en">

  <head>

    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Aplikasi Cetak Undangan</title>

    <!-- Bootstrap core CSS -->
    <link href="vendor/bootstrap/css/bootstrap.min.css" rel="stylesheet">
    <link href="vendor/bootstrap/css/style.css" rel="stylesheet">

    <!-- Custom styles for this template -->
    <link href="css/small-business.css" rel="stylesheet">

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>

<link href="" rel="stylesheet">


 <script src="http://desa.kemendesa.go.id/themes/managerdesav2/js/dataTables1/jquery.dataTables.min.js"></script>
 <script src="http://desa.kemendesa.go.id/themes/managerdesav2/js/dataTables1/dataTables.bootstrap.min.js"></script>


<script type="text/javascript">
$("#table-data1").dataTable({
	"pageLength": 5,
	"sPaginationType": "numbers",
    "paging":  true,
    "ordering": false,
    "info":     false,
    "filter":false,
    "lengthChange":false,
  } );

$("#table-data2").dataTable({
	"pageLength": 5,
	"sPaginationType": "numbers",
    "paging":  true,
    "ordering": false,
    "info":     false,
    "filter":false,
    "lengthChange":false,
  } );

$("#table-data3").dataTable({
	"pageLength": 5,
	"sPaginationType": "numbers",
    "paging":  true,
    "ordering": false,
    "info":     false,
    "filter":false,
    "lengthChange":false,
  } );

$("#table-data4").dataTable({
	"pageLength": 5,
	"sPaginationType": "numbers",
    "paging":  true,
    "ordering": false,
    "info":     false,
    "filter":false,
    "lengthChange":false,
  } );


</script>


<style>
.partner {
    padding: 30px 0 !important;
    background: #ffffff;
    color: #000000;
}

.partner img {
    max-width: 100% !important;
    max-height: 70px !important;
    display: block;
    margin: 0 auto;
}
</style>


  </head>

  <body>

    <!-- Navigation -->
    <nav class="navbar navbar-expand-lg navbar-dark bg-dark fixed-top">
      <div class="container">
        <a class="navbar-brand" href="index.php">Aplikasi Cetak Label Undangan</a>
        <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarResponsive" aria-controls="navbarResponsive" aria-expanded="false" aria-label="Toggle navigation">
          <span class="navbar-toggler-icon"></span>
        </button>
        <div class="collapse navbar-collapse" id="navbarResponsive">
          <ul class="navbar-nav ml-auto">
            <li class="nav-item active">
              <a class="nav-link" href="index.php">HOME
                <span class="sr-only">(current)</span>
              </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="cetak.php" target="output">CETAK </a>
            </li>
            <li class="nav-item">
              <a class="nav-link" href="import.php">IMPORT DATA (EXCEL)</a>
            </li>
			
			 <li class="nav-item">
              <a class="nav-link" href="viewdata.php">HAPUS DATA</a>
            </li>

          </ul>
        </div>
      </div>
    </nav>